import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  fullForm: FormGroup;
  countries  = ["Congo", "Brazza"];

  items = Array.from({ length: 10 }).map((_, i) => ({
    id: i,
    label: `Programming Lang #${i}`
  }));

  change($event: any) {
  }

  preferedProgrammingLanguage: string;
  preferedJavaScriptFrameworks: string[];

  ProgrammingLanguages: Observable<string[]> = of([
    'C#',
    'Java',
    'VB',
    'Python',
    'Javascript',
    'Typescript',
  ]);
  JavaScriptFrameworks: Observable<string[]> = of([
    'vueJS',
    'AngularJS',
    'ReactJS',
  ]);

  constructor() {}

  ngOnInit(): void {
    this.fullForm = new FormGroup({
      searchSingleEnabled: new FormControl(false, Validators.required),
      collapseOnSelect: new FormControl(false, Validators.required),
      singleSelect: new FormControl([], Validators.required),

      searchMultiEnabled: new FormControl(false, Validators.required),
      selectAllEnabled: new FormControl(false, Validators.required),
      multiSelect: new FormControl([], Validators.required)
    });
  }
}
