import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SingleselecComponent } from './singleselec.component';

describe('SingleselecComponent', () => {
  let component: SingleselecComponent;
  let fixture: ComponentFixture<SingleselecComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SingleselecComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SingleselecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
