import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { Ng2SmartTableModule  } from  'ng2-smart-table';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MultiselectComponent } from './components/multiselect/multiselect.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutofocusDirective } from './autofocus.directive';
import { SingleselecComponent } from './singleselec/singleselec.component';

@NgModule({
  declarations: [AppComponent, MultiselectComponent, AutofocusDirective, SingleselecComponent],
  imports: [BrowserModule, AppRoutingModule, FormsModule, ReactiveFormsModule,ScrollingModule,Ng2SmartTableModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
